package hw4.HaqueI;
import java.time.LocalDate;
abstract class Employee {
 private String name,id;
 int year,month,day;
 private LocalDate hireDate;
  public Employee(){
	name=null;  
	id=null;
	hireDate=null;
  }
  public Employee(String name,String id,int year,int month, int day) {
    this.year=year;
    this.month=month;
    this.day=day;
	this.name=name;
    this.id=id;
    hireDate=LocalDate.of(this.year, this.month, this.day);
    
  }
  public String getName() {
	return "Employee name: "+ name;  
  }
  public void changeName(String name) {
   this.name=name;
  }
  public LocalDate getHireDate() {
	return hireDate;
  }
  public String getid() {
   return id;
  }
  public String toString() {
	 return "Employee name: "+ name+" Id: "+id+" Hired Date:"+ month+"/"+day+"/"+year; 
  }
  public abstract double pay();
  
}