package hw4.HaqueI;

import java.time.LocalDate;

public class FulltimeEmployee extends Employee {
  double payRate;
  int hoursWorked;
  public FulltimeEmployee() {
	super();
	hoursWorked=0;
	payRate=0;
  }
  public FulltimeEmployee(String name, String id, int year, int month,int day,int hoursWorked,double payRate) {
	  super(name,id,year,month,day);
	  this.hoursWorked=hoursWorked;
	  this.payRate=payRate;
  }
  public void changeHoursWorked(int hours) {
		hoursWorked=hours;  
  }
  public double OverTime() {
	if((hoursWorked<40)||(hoursWorked==40)) return 0.0;
	else if(hoursWorked>40) return (hoursWorked-40)*1.5*payRate;
	return 0.0;
  }
  public double pay() {
		if(hoursWorked<40) return hoursWorked*payRate;
		if(hoursWorked>=40) return (40*payRate)+OverTime();
		return 0.0;
  } 
  public void changepayRate(double rate){
		payRate=rate;  
  }
  public double returnpayRate() {
	   return payRate;
  }
  public int returnhoursWorked(){
	return hoursWorked;	
  }
  public String findName() {
    return getName();
  }
  public String findid() {
		return getid();	
  }
  public LocalDate findDate() {
		return getHireDate();  
  }
  public String toString() {
	    return "Full Time "+ getName()+" Id: "+getid()+" Hired Date:"+ month+"/"+day+"/"+year+" Salary: "+payRate+" Total Pay: "+pay()+" Hours Worked: "+hoursWorked; 
  }
  public double Overtimereturn() {
	  return OverTime();
  }
}
