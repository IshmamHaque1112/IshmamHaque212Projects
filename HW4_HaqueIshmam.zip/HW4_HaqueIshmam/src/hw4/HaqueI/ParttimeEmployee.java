package hw4.HaqueI;

import java.time.LocalDate;

public class ParttimeEmployee extends Employee {
	  double payRate;
	  int hoursWorked;
	  public ParttimeEmployee() {
		super();
		hoursWorked=0;
		payRate=0;
	  }
	  public ParttimeEmployee(String name, String id, int year, int month,int day,int hoursWorked,double payRate) {
		  super(name,id,year,month,day);
		  this.hoursWorked=hoursWorked;
		  this.payRate=payRate;
	  }
	  public void changeHoursWorked(int hours) {
			hoursWorked=hours;  
	  }
	  public double pay() {
			return (hoursWorked*payRate);
	  } 
	  public void changepayRate(double rate){
			payRate=rate;  
	  }
	  public double returnpayRate() {
		   return payRate;
	  }
	  public int returnhoursWorked(){
		return hoursWorked;	
	  }
	  public String findName() {
	    return getName();
	  }
	  public String findid() {
			return getid();	
	  }
	  public LocalDate findDate() {
			return getHireDate();  
	  }
	  public String toString() {
		    return "Part Time "+ getName()+" Id: "+getid()+" Hired Date:"+ month+"/"+day+"/"+year+" Salary: "+payRate+" Total Pay: "+pay()+" Hours Worked: "+hoursWorked; 
	  }
}
