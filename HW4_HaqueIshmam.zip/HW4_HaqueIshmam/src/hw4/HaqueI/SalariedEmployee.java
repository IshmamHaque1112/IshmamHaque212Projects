package hw4.HaqueI;

import java.time.LocalDate;

public class SalariedEmployee extends Employee {
  private double salary;
  public SalariedEmployee() { 
	super();  
	salary=0;	
  }
  public SalariedEmployee(String name, String id, int year, int month,int day, double salary) {
	  super(name,id,year,month,day);
	  this.salary=salary;
  }
  public double pay() {
	return salary;  
  }
  public void raisetheSalary() {
	salary=salary*1.07;
  }
  public double returnsalary() {
   return salary;
  }
  public String findName() {
	return getName();
  }
  public String findid() {
	return getid();	
  }
  public LocalDate findDate() {
	return getHireDate();  
  }
  public String toString() {
    return "Salaried "+ getName()+" Id: "+getid()+" Hired Date:"+ month+"/"+day+"/"+year+" Salary: "+salary; 
  }
}
