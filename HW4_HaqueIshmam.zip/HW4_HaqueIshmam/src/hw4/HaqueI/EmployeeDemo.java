package hw4.HaqueI;

public class EmployeeDemo {

	public static void main(String[] args) {
		FulltimeEmployee a= new FulltimeEmployee("Timothy","2877",2018,1,21,50,45.5);
		SalariedEmployee b= new SalariedEmployee("Derek","7869",1988,5,14,21.60);
		ParttimeEmployee c= new ParttimeEmployee("Lionel","90560",1974,5,10,60,78.9);
	    FulltimeEmployee d= new FulltimeEmployee("Wilhelm","1914567",1918,9,26,89,60);
	    SalariedEmployee e= new SalariedEmployee("Gaddafi","97971",1969,4,18,45.60);
	    ParttimeEmployee f= new ParttimeEmployee("Lopez","1989",1421,7,18,76,45.78);
        System.out.println(c.getName());
        System.out.println(a.findDate());
        System.out.println(f.getid());
        System.out.println(c.toString());
        b.raisetheSalary();
        d.changepayRate(100);
        System.out.println(d.toString());
        System.out.println(e.toString());
        System.out.println(a.toString());
	}

}
