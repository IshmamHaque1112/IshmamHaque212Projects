package hw5.haqueI;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;
public class EmployeeRecord {
 public static boolean isValidDigit(String s) throws SSNCharacterException {
  try {
	 for(int i=0;i<9;i++) {
		char currentchar=s.charAt(i);
		int charascii=(int) currentchar;
		if((charascii<48)||(charascii>57)) throw new SSNCharacterException("Character isn't numeric char.");
	 }
	 return true;
   }
	 catch(SSNCharacterException a) {
	   System.out.println("The ssn must be three digits first,then two digits, then four digits. Hyphens optional in between.Input again.");
	   return false;
	 }
 }
 public static boolean isValidLength(String s) throws SSNLengthException {
  try {	 
   int ssnlength=s.length();
   if(ssnlength==9) return true;
   if(ssnlength<9) throw new SSNLengthException("Too short");
   if(ssnlength>9) throw new SSNLengthException("Too long");
   return true;
  }
  catch(SSNLengthException a) {
   System.out.println("Must be total length of 9. Input again");
   return false;
  }
 }
 public static String removehyphens(String s){
	 String newSSN ="";
	 int stringlength=s.length();
	 for(int i=0;i<stringlength;i++) {
		if(s.charAt(i)!='-') newSSN+=s.charAt(i); 
	 }
	 return newSSN;
 }
 public static void main(String[] args) throws SSNCharacterException, SSNLengthException {
	ArrayList<Employee> employed=new ArrayList<>();
	System.out.println("Input the number of employees you want to put in");
	Scanner scan=new Scanner(System.in);
	double total=0;
	int numofemployees;
	numofemployees=scan.nextInt();
	if((numofemployees>100) ||(numofemployees<=0)) {
	 System.out.println("Too many or too little. Min 1. Max 100. Input again");
	 numofemployees=scan.nextInt();
	}
	else if((numofemployees<=100) && (numofemployees>0)) {
	 for(int i=0;i<numofemployees;i++) {
		System.out.println("Input name, ssn, position,year,month, day, and salary for Employee "+(i+1)); 
		String name,SSN,position;
		int year,month,day;
		double salary;
		name=scan.next();
		System.out.println(name);
		SSN=scan.next();
		while(!isValidLength(removehyphens(SSN))) SSN=scan.next();
		while(!isValidDigit(removehyphens(SSN))) SSN=scan.next();
		if((isValidDigit(removehyphens(SSN))&&(isValidLength(removehyphens(SSN))))) {
		  System.out.println(SSN);	
		  position=scan.next();
		  System.out.println(position);
		  year=scan.nextInt();
		  System.out.println(year);
		  month=scan.nextInt();
		  System.out.println(month);
		  day=scan.nextInt();
		  System.out.println(day);
		  salary=scan.nextDouble();
		  total+=salary;
		  System.out.println(salary);
		  employed.add(new Employee(name,SSN,year,month,day,salary,position));
		  System.out.println("Employee "+(i+1)+" "+employed.get(i).toString());
		}
	  }	 
	}
	double average=total/numofemployees;
	for(int i=0;i<numofemployees;i++) {
	  System.out.println("Employee "+(i+1)+" "+employed.get(i).toString());
	}
	System.out.println("Which employee do you want to find salary");
	int salaryemployee=scan.nextInt();
	System.out.println("Employee "+ (salaryemployee)+" "+employed.get(salaryemployee-1).getSalary());
	if(employed.get(salaryemployee-1).getSalary()<average) System.out.println("Lower than average "+average);
	if(employed.get(salaryemployee-1).getSalary()>average) System.out.println("Bigger than average "+average);
	if(employed.get(salaryemployee-1).getSalary()==average) System.out.println("Equal to average "+average);
	scan.close();
 }
}