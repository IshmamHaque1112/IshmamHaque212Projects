package hw5.haqueI;

public class SSNCharacterException extends Exception {
	public SSNCharacterException(String s) {
		super(s);
	}
}
