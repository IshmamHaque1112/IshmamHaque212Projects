package hw5.haqueI;

public class SSNLengthException extends Exception {
	public SSNLengthException(String s) {
		super(s);
	}
}
