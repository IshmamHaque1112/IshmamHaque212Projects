package hw5.haqueI;

public class Employee extends Person {
 String position;
 double salary;
 Employee(){
  position=null;
  salary=0;
 }
 Employee(String name,String SSN,int year, int month, int day,double salary, String position){
	super(name,SSN,year,month,day);
	this.salary=salary;
	this.position=position;
 }
 public double getSalary(){
	return salary; 
 }
 public String getPosition() {
	return position; 
 }
 public void changeSalary(double salary) {
	this.salary=salary; 
 }
 public String toString() {
  return "Name: "+name+" Social Security Number: "+SSN+" Position:"+position+" Salary: "+salary+" "+month+"/"+day+"/"+year;	 
 }
}
