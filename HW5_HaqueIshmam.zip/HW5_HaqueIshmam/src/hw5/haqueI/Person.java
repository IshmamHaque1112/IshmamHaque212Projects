package hw5.haqueI;
import java.time.LocalDate;
abstract class Person {
 String name,SSN;
 int year,month,day;
 LocalDate Hiredate;
  Person(){
   name=null;
   SSN=null;
   Hiredate=null;
  }
  Person(String name,String SSN,int year, int month, int day){
	this.name=name;
	this.SSN=SSN;
	this.year=year;
	this.month=month;
    this.day=day;
    Hiredate=LocalDate.of(this.year, this.month, this.day);
  }
  public String getName(){
	return name;  
  }
  public String getSSN() {
	return SSN; 
  }
  public LocalDate findDate(){
	  return Hiredate;
  }
  public void changeName(String name) {
	this.name=name;  
  }
}
