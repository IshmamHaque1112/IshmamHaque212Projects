package hw1.HaqueI;
import java.util.Scanner;
public class homework_1 {
 public static void printCode(String a,int key,int length) {
  String decoded="";
  for(int i=0;i<length;i++) {
   char b=a.charAt(i);
   char decodedletter;
   if((b-key)<32) {
	 decodedletter=(char)(b-32+127-key);
	 decoded=decoded+decodedletter;
   }
   else {
	decodedletter=(char)(b-key);
    decoded=decoded+decodedletter;
   }
  }
 System.out.println(decoded);
 }
 public static void main(String[] args) {
  int e,temp,count,f,countlength;
  double a,b,c,d, solution1, solution2;
  String codedmessage;
  Scanner quadratic= new Scanner(System.in);
  System.out.println("a(x^2) + bx + c = 0");
  System.out.println("Please input the values for the quadratic");		
  System.out.println("Input A,then B, then C");
  a=quadratic.nextDouble();
  b=quadratic.nextDouble();
  c=quadratic.nextDouble();
  d=((b*b)-(4*a*c));
  if(d<0) System.out.println("No solutions");
  if(d>=0) {
   solution1=(-b+Math.sqrt(d))/(2*a);
   solution2=(-b-Math.sqrt(d))/(2*a);
   System.out.println(solution1+" and "+solution2);
  }
  System.out.println("Let's play the Hailstone. Input the values.");
  Scanner hailstone= new Scanner(System.in);
  e=hailstone.nextInt();
  count=0;
  while(e>=0) {
   if(e%2==0) {
	temp=e;
	e=e/2;
	count++;
	System.out.println(temp+" is even so I half it. "+e);
   }
   if((e%2!=0) &&(e!=1)) {
	temp=e;
    e=(3*e)+1;
    count++;
    System.out.println(temp+" is odd so I do 3e+1. "+e);
   }
   if(e==1) {
    f=count;
    System.out.println("It took "+f+" steps to reach 1");
	break;
   }
  }
  Scanner readcode=new Scanner(System.in);
  System.out.println("Input the code: ");
  codedmessage=readcode.nextLine();
  countlength=codedmessage.length();
  for(int i=1;i<=100;i++) {
	printCode(codedmessage,i,countlength);
  }
  }
 }
