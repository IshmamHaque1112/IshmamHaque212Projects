package hw2.HaqueI;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
public class homework_2 extends Application {
 int bricksinbase=12;
 int brickswidth=30;
 int bricksheight=12;
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,400,400);
			// Pass the canvas object including blicks to the root of Scene here.
			root.getChildren().add(homework_2.drawShape(400, 400, brickswidth,bricksheight,bricksinbase));
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	/*
	 * This method draws a half triangle on the left side.
	 * Use strokeRect method to draw a square block.
	 * The input of strokeRect method is (x_coordinate, y_coordinate, width, height)
	 * Your task is to change this method so that it prints out a pyramid in a way the instruction says
	 */
	public static Canvas drawShape(int canvas_width, int canvas_height, int blick_width, int blick_height,int blicksinbase) {
		Canvas canvas = new Canvas(canvas_width, canvas_height);
		GraphicsContext gc = canvas.getGraphicsContext2D();
		for(int row=0;row<=blicksinbase;row++) {
			for(int col=0;col<row;col++) {
				int x= ((blicksinbase*blick_width)/2)-((blick_width/2)*row) + (col*blick_width);
		        int y= blick_height*row;
					gc.strokeRect(x+20, y+(canvas_height-(blick_height*blicksinbase)-blick_height), blick_width, blick_height);
					
			}
		}	
		return canvas;
	}
	
}
