package hw3.HaqueI;
import java.util.Random;

public class Die {
	public static int dienumber;
	Random roll=new Random();
	
	public Die(){
		 dienumber=1;
	}
	
	public void rollDie(){
		dienumber=(((int)(roll.nextInt(6)+1)));
	}
	
	public int getDie(){
		return dienumber;
	}
}
