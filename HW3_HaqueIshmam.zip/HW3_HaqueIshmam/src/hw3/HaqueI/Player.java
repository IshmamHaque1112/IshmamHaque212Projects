package hw3.HaqueI;
public class Player {
	private int playerscore;
	private String playername;

	public Player() {
		playername="N/A";
		playerscore=50;
	}
 
	public Player(String name) {
		playername=name;
		playerscore=50;
	}

	public void changeScore(int dieroll){
		playerscore=playerscore-dieroll;
	}

	public int getScore() {
		return playerscore;
	}
	

	public String getName(){
		return playername;  
	}
}
