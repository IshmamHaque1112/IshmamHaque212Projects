package hw3.HaqueI;
import java.util.Scanner;
import java.util.ArrayList;

public class FirstToOneGame {
	
	public static int takeTurn(int a,int b) {
		return ((a+1)%b);
	}
	
	public static boolean gameinPlay(ArrayList<Player> a) {
		int score;
		for(Player b:a){
			score=b.getScore();  
			if(score==1) {
				return true;
			}
		}
		return false;
	}

	public static void winplayer(ArrayList<Player> a) {
		int score;
		int i=0;
		for(Player b:a){
			score=b.getScore();	  
			if(score==1){
				System.out.println("Player "+(i+1)+" "+b.getName()+" wins.");
				break;
			}
			i++;
		}
	}

	public static void main(String[] args) {
		int numofplayers;
		String username = "";
		Die dice=new Die();
		int rollednumber, current_player=0;

		Scanner scan = new Scanner(System.in);
		System.out.print("Input the number of players in this game: ");
		numofplayers=scan.nextInt();
		ArrayList <Player> playerlist=new ArrayList<>();
		System.out.println("There are "+numofplayers+" players.");
        System.out.println("-----------------------------------");
		for(int i=0;i<numofplayers;i++) {
			System.out.print("Input Player "+ (i+1)+": ");
			username = scan.next();
			playerlist.add(new Player(username));
			System.out.println("Player "+(i+1)+" is "+username);
			System.out.println("---------------------------");
		} 
		scan.close();
		while(gameinPlay(playerlist)==false) {
			System.out.println("Player "+(current_player+1)+" "+ playerlist.get(current_player).getName()+" has points: "+playerlist.get(current_player).getScore());
			dice.rollDie();
			rollednumber=dice.getDie();
			System.out.println("The player rolled a: "+rollednumber);
			if (playerlist.get(current_player).getScore()-rollednumber<0)  
				playerlist.get(current_player).changeScore(rollednumber*-1);
			else 
				playerlist.get(current_player).changeScore(rollednumber);
			System.out.println("Player "+(current_player+1)+" "+ playerlist.get(current_player).getName()+" new points are: "+playerlist.get(current_player).getScore());
			System.out.println("------------------------------------------------------------------");
			current_player=takeTurn(current_player,numofplayers);
			if(gameinPlay(playerlist)) {
				winplayer(playerlist);
			}
		}
	}//main
	
}//class
