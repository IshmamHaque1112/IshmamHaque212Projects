package hw6.haqueI;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class Main extends Application {
     Double number1,number2,total,memorizednumber;
     String operation;
    @Override
    public void start(Stage stage) {
    	
    	BorderPane root = new BorderPane();
    	Scene scene = new Scene(root, 370, 320);

	// Textfield on the top to show calculations
    	TextField tf = new TextField();
	// Set the object on the top
    	root.setTop(tf);

	// VBox for arithmetic operator buttons
    	VBox vbox = new VBox();
	// Set spaces around the object
	vbox.setSpacing(5);
	vbox.setPadding(new Insets(10, 10, 10, 10));
	// Buttons for arithmetic operation
    	Button plus = new Button("+");
    	Button minus = new Button("-");
    	Button multiply = new Button("*");
    	Button division = new Button("/");
    	plus.setMinSize(50, 50);
    	minus.setMinSize(50, 50);
    	multiply.setMinSize(50, 50);
    	division.setMinSize(50, 50);
    	// Set buttons in the box and vbox on the left
    	vbox.getChildren().addAll(plus, minus, multiply, division);
    	root.setLeft(vbox);

	// GripPane for function buttons
    	GridPane gp = new GridPane();
	// Set spaces around the object
	gp.setVgap(5);
	gp.setPadding(new Insets(10, 10, 10, 10));
    	// Buttons for functions
	Button clear = new Button("C");
    	clear.setMinSize(50, 50);
    	gp.add(clear,  0, 0);
    	Button memory = new Button("M");
    	memory.setMinSize(50, 50);
    	gp.add(memory,  0, 1);
    	Button exit = new Button("E");
    	exit.setMinSize(50, 50);
    	gp.add(exit,  0, 2);
    	Button recall = new Button("R");
    	recall.setMinSize(50, 50);
    	gp.add(recall,  0, 3);
    	Button equal = new Button("=");
    	equal.setMinSize(50, 50);
    	gp.add(equal,  0, 4);
    	// Set the object on the right
	root.setRight(gp);

	// Array of buttons to store number button objects
	Button [] number_buttons = new Button[10];
	// GridPane for number buttons
	GridPane numbers = new GridPane();
	// Set spaces around the object
	numbers.setVgap(5);
	numbers.setHgap(5);
	numbers.setPadding(new Insets(10, 10, 10, 10));
	// Position the number buttons at the center
	numbers.setAlignment(Pos.TOP_CENTER);
	// Instantiate number buttons from 1 to 9
	for(int i=0; i<3; i++) { 
		for(int j=0; j<3; j++) { 
			int index = (i*3) + j;
			number_buttons[index] = new Button(Integer.toString(index+1));
			number_buttons[index].setMinSize(60, 65);
			// Set the font of button
			number_buttons[index].setStyle("-fx-font: 15 arial;");
			numbers.add(number_buttons[index], j, i);
		}
	}	
	// Instantiate a button for 0
	number_buttons[9] = new Button("0");
	number_buttons[9].setMinSize(60, 60);
	number_buttons[9].setStyle("-fx-font: 15 arial;");
	numbers.add(number_buttons[9], 1, 3);
   	// Set the gridpane at the center
	root.setCenter(numbers);

	// Set action on "0" button (i.e.) when it's clicked, the background color changes to green. Your task is to set action on all buttons.
	number_buttons[9].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[9].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[0].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[0].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[1].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[1].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[2].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[2].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[3].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[3].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[4].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[4].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[5].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[5].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[6].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[6].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[7].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[7].getText();
			tf.setText(EnterNumber);
		}
	});
	number_buttons[8].setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText()+number_buttons[8].getText();
			tf.setText(EnterNumber);
		}
	});
	plus.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText();
			operation="+";
			number1=Double.parseDouble(EnterNumber);
			tf.setText("");
		}
	});
	minus.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText();
			operation="-";
			number1=Double.parseDouble(EnterNumber);
			tf.setText("");
		}
	});
	multiply.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText();
			operation="*";
			number1=Double.parseDouble(EnterNumber);
			tf.setText("");
		}
	});
	division.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber=tf.getText();
			operation="/";
			number1=Double.parseDouble(EnterNumber);
			tf.setText("");
		}
	});
	clear.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String EnterNumber="";
			number1=0.0;
			operation="";
			tf.setText(EnterNumber);
		}
	});
	equal.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			total=0.0;
			String InputText= tf.getText();
			number2=Double.parseDouble(InputText);
			if(operation=="+") total=number1+number2;
			if(operation=="-") total=number1-number2;
			if(operation=="*") total=number1*number2;
			if(operation=="/") total=number1/number2;
			tf.setText(String.valueOf(total));
		}
	});
	memory.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			String InputText=tf.getText();
			memorizednumber=Double.parseDouble(InputText);
		}
	});
	recall.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			tf.setText(String.valueOf(memorizednumber));
		}
	});
	exit.setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
		public void handle(ActionEvent e) {
			System.exit(0);
		}
	});
	stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

}